package com.wikia.webdriver.common.skin;

public enum Skin {
  OASIS, DISCUSSIONS, MOBILE_WIKI
}
