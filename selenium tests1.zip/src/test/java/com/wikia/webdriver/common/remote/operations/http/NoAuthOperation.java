package com.wikia.webdriver.common.remote.operations.http;

public class NoAuthOperation extends PostRemoteOperation {

  public NoAuthOperation() {
    super(null);
  }
}
