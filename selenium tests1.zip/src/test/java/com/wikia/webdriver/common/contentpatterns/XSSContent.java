package com.wikia.webdriver.common.contentpatterns;

public class XSSContent {

  public static final String NO_JQUERY_ERROR = "ReferenceError: $ is not defined";

  private XSSContent() {

  }
}
