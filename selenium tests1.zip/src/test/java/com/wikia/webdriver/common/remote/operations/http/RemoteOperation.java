package com.wikia.webdriver.common.remote.operations.http;

public interface RemoteOperation {

  String execute(final String url);
}
