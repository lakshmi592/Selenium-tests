package com.wikia.webdriver.common.logging;

public interface LogData {

  String cssClass();
}
