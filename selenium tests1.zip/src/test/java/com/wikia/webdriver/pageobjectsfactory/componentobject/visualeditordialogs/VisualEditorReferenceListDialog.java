package com.wikia.webdriver.pageobjectsfactory.componentobject.visualeditordialogs;

import org.openqa.selenium.WebDriver;

public class VisualEditorReferenceListDialog extends VisualEditorDialog {

  public VisualEditorReferenceListDialog(WebDriver driver) {
    super(driver);
  }
}
