package com.wikia.webdriver.pageobjectsfactory.pageobject.special;

/**
 * Created by ryba on 12/06/2017.
 */
public class SpecialAdminDashboardPageObject {

}
