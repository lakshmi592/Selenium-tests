package com.wikia.webdriver.pageobjectsfactory.componentobject.visualeditordialogs;

import org.openqa.selenium.WebDriver;

public class VisualEditorReferenceDialog extends VisualEditorDialog {

  public VisualEditorReferenceDialog(WebDriver driver) {
    super(driver);
  }
}
