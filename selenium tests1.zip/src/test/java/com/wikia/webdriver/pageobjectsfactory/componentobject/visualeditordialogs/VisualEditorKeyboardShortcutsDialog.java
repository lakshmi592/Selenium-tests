package com.wikia.webdriver.pageobjectsfactory.componentobject.visualeditordialogs;

import org.openqa.selenium.WebDriver;

public class VisualEditorKeyboardShortcutsDialog extends VisualEditorDialog {

  public VisualEditorKeyboardShortcutsDialog(WebDriver driver) {
    super(driver);
  }
}
