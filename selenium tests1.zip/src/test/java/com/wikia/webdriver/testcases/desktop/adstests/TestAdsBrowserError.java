package com.wikia.webdriver.testcases.desktop.adstests;

import com.wikia.webdriver.common.core.Assertion;
import com.wikia.webdriver.common.core.elemnt.JavascriptActions;
import com.wikia.webdriver.common.dataprovider.ads.AdsDataProvider;
import com.wikia.webdriver.common.templates.TemplateNoFirstLoad;
import com.wikia.webdriver.pageobjectsfactory.pageobject.adsbase.AdsBaseObject;

import org.testng.annotations.Test;

public class TestAdsBrowserError extends TemplateNoFirstLoad {

  @Test(groups = "AdsScrollHandlerBrowserError")
  public void adsScrollHandlerBrowserError() {
    JavascriptActions jsActions = new JavascriptActions(driver);

    String testPage = AdsDataProvider.UAP_PAGE.getUrl();
    testPage = urlBuilder.appendQueryStringToURL(testPage, "scrollhandler=1");
    AdsBaseObject adsBaseObject = new AdsBaseObject();
    adsBaseObject.getUrl(testPage);

    jsActions.addErrorListenerScript();
    jsActions.waitForJavaScriptTruthy("window.scrollY == 0");
    jsActions.scrollBy(0, 5001);
    jsActions.waitForJavaScriptTruthy("window.scrollY != 0");

    Assertion.assertEquals(jsActions.getWindowErrors(), "");
  }
}
