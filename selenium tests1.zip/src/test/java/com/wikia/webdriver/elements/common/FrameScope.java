package com.wikia.webdriver.elements.common;

@FunctionalInterface
public interface FrameScope {

  void execute();
}
