package com.wikia.webdriver.elements.communities.mobile.components.discussions.desktop;

import com.wikia.webdriver.pageobjectsfactory.pageobject.BasePageObject;

public class HeroUnit extends BasePageObject {

}
