package com.wikia.webdriver.elements.communities.mobile.components.discussions.common;

public final class DiscussionsConstants {

  public static final long TIMEOUT = 10;

  private DiscussionsConstants() {
    throw new AssertionError();
  }
}
