package com.wikia.webdriver.elements.communities.mobile.pages.curatedcontent;

import com.wikia.webdriver.common.contentpatterns.MercuryMessages;
import com.wikia.webdriver.common.logging.Log;
import com.wikia.webdriver.pageobjectsfactory.pageobject.BasePageObject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * This class represents all the levels below Curated Main Page
 */
public class CuratedContentPageObject extends BasePageObject {

  @FindBy(css = ".wiki-page-title")
  private WebElement sectionTitle;
  @FindBy(css = ".curated-content-section__back")
  private WebElement linkToMainPage;
  @FindBy(css = ".curated-content-section:not(.wds-is-hidden) .curated-content-items")
  private WebElement sectionContainer;
  @FindBy(css = ".curated-content .curated-content-section:not(.wds-is-hidden) "
                + ".curated-content-item .item-figure")
  private List<WebElement> curatedContentItems;

  public int getCuratedContentItemsNumber() {
    wait.forElementVisible(curatedContentItems.get(0));
    return curatedContentItems.size();
  }

  public CuratedContentPageObject clickOnCuratedContentElementByIndex(int elementNumber) {
    wait.forElementVisible(curatedContentItems.get(elementNumber));
    jsActions.scrollToElement(curatedContentItems.get(elementNumber));
    curatedContentItems.get(elementNumber).click();
    return this;
  }

  public CuratedContentPageObject isTitleVisible() {
    wait.forElementVisible(sectionTitle);
    Log.info(Labels.SECTION_TITLE.name + " " + MercuryMessages.VISIBLE_MSG);
    return this;
  }

  public CuratedContentPageObject isLinkToMainPageVisible() {
    wait.forElementVisible(linkToMainPage);
    Log.info(Labels.LINK_TO_MAIN_PAGE.name + " " + MercuryMessages.VISIBLE_MSG);
    return this;
  }

  public CuratedContentPageObject isSectionVisible() {
    wait.forElementVisible(sectionContainer);
    Log.info(Labels.SECTION.name + " " + MercuryMessages.VISIBLE_MSG);
    return this;
  }

  public CuratedContentPageObject isCuratedContentItemVisibleByIndex(int elementNumber) {
    wait.forElementVisible(curatedContentItems.get(elementNumber));
    Log.info(Labels.SECTION_ITEM.name + " " + MercuryMessages.VISIBLE_MSG);
    return this;
  }

  private enum Labels {
    ARTICLE("Article wrapper"), SECTION_TITLE("Section title"), LINK_TO_MAIN_PAGE(
        "Link to main page"), SECTION("Section as the container of many elements"), SECTION_ITEM(
        "Item in a section"), LOAD_MORE_BUTTON("Load more button"), NUMBER_OF_ITEMS(
        "Number of items in curated content section"), ITEM_LABELS("Curated Content items labels");

    private String name;

    Labels(String name) {
      this.name = name;
    }
  }
}
