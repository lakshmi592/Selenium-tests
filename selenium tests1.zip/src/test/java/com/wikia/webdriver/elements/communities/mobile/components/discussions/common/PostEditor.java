package com.wikia.webdriver.elements.communities.mobile.components.discussions.common;

import com.wikia.webdriver.pageobjectsfactory.pageobject.BasePageObject;

public class PostEditor extends BasePageObject {

}
